# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Extractor por Junji.
#
# Extractor para Kodi es un software libre: puedes redistribuirlo y/o modificarlo
# bajo los términos de la Licencia Pública General GNU, según lo publicado por
# la Free Software Foundation, ya sea la versión 3 de la Licencia, o
# (a tu opción) cualquier versión posterior.
#
# Deberías haber recibido una copia de la Licencia Pública General GNU junto
# con este programa. Si no, consulta <http://www.gnu.org/licenses/>.
#
#-------------------------------------------------------------------------------
#
# Exención de Responsabilidad
#
# Este addon solo proporciona acceso a contenido público y legal a través de
# una URL de acceso libre. El usuario es responsable del contenido al que
# accede utilizando este addon. No promovemos ni apoyamos el uso ilegal de 
# este addon.
#
# Por favor, utilice el addon de acuerdo con las leyes locales, y respete 
# los derechos de propiedad intelectual.
#-------------------------------------------------------------------------------


import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests
from bs4 import BeautifulSoup
import re
from urllib.parse import urlencode, urlparse, parse_qsl

ADDON = xbmcaddon.Addon()
if len(sys.argv) > 1:
    ADDON_HANDLE = int(sys.argv[1])
else:
    ADDON_HANDLE = -1  # O cualquier otro valor por defecto que consideres seguro

BASE_URL = sys.argv[0]
SCRAPER_URL = ADDON.getSetting('scraper_url')


def is_valid_url(url):
    """Comprueba si una URL es válida."""
    parsed = urlparse(url)
    return all([parsed.scheme, parsed.netloc])


def fetch_html_content(url):
    """Obtiene el contenido HTML de una página dada."""
    try:
        response = requests.get(url)
        response.raise_for_status()
        return response.text
    except requests.RequestException as e:
        xbmc.log(f'Error al acceder a la página: {e}', xbmc.LOGERROR)
        return None


def extract_magnets_and_acestreams_from_row(row):
    """Extrae los enlaces Magnet y Acestream de una fila dada."""
    magnets = []
    acestreams = []
    links = row.find_all('a', href=True)

    for link in links:
        href = link.get('href', '')
        if 'magnet:' in href:
            magnet_hash = re.search(r'btih:[a-fA-F0-9]{40}', href)
            if magnet_hash:
                magnets.append(f"magnet:?xt=urn:{magnet_hash.group()}")
        elif 'acestream://' in href:
            acestreams.append(href)

    # Verificar hashes de Acestream directamente
    cols = row.find_all('td')
    if not links and len(cols) >= 2:
        raw_hash = cols[-1].text.strip()
        if len(raw_hash) == 40:  # Verificar si es un hash SHA-1
            acestreams.append(f"acestream://{raw_hash}")

    return magnets, acestreams


def extract_m3u_links(html_content):
    """Extrae enlaces de tipo m3u del contenido HTML."""
    streams = []
    lines = html_content.splitlines()

    current_stream = {}
    for line in lines:
        if line.startswith("#EXTINF:"):
            # Extraer metadatos de la línea #EXTINF
            match = re.search(r'tvg-logo="([^"]*)",(.+)', line)
            if match:
                logo_url, title = match.groups()
                current_stream = {
                    "title": title.strip(),
                    "logo": logo_url.strip(),
                    "links": []
                }
        elif line.startswith("acestream://"):
            # Si es un link acestream, lo añadimos al stream actual
            if current_stream:
                current_stream["links"].append(line.strip())
                streams.append(current_stream)
                current_stream = {}  # Limpiar para el siguiente stream

    return streams


def extract_stream_info(url):
    """Extrae la información de streams (Magnet y Acestream) de una página dada."""
    html_content = fetch_html_content(url)
    if not html_content:
        return []

    soup = BeautifulSoup(html_content, 'html.parser')
    streams = []

    # Buscar todas las tablas
    tables = soup.find_all('table')

    if tables:
        # Recorrer todas las tablas para encontrar enlaces
        for streams_table in tables:
            rows = streams_table.find_all('tr')[1:]  # Ignorar la cabecera
            for row in rows:
                cols = row.find_all('td')
                if len(cols) >= 2:  # Asegurarse de que haya suficientes columnas
                    stream_info = " - ".join([col.text.strip() for col in cols[:-1]])
                    magnets, acestreams = extract_magnets_and_acestreams_from_row(row)

                    if magnets or acestreams:
                        streams.append((stream_info, magnets + acestreams))

    # Buscar enlaces magnet fuera de las tablas (en listas no ordenadas)
    unordered_lists = soup.find_all('ul')
    for unordered_list in unordered_lists:
        list_items = unordered_list.find_all('li')
        for item in list_items:
            magnets = item.find_all('a', href=True)
            for magnet in magnets:
                href = magnet['href']
                if 'magnet:' in href:
                    magnet_hash = re.search(r'btih:[a-fA-F0-9]{40}', href)
                    if magnet_hash:
                        magnet_clean = f"magnet:?xt=urn:{magnet_hash.group()}"
                        title = item.get_text(strip=True).split('(torrent file)')[0].strip()
                        streams.append((title, [magnet_clean]))

    # Procesar enlaces tipo m3u si existen
    m3u_streams = extract_m3u_links(html_content)
    if m3u_streams:
        for stream in m3u_streams:
            streams.append((stream["title"], stream["links"]))

    return streams


def build_url(query):
    """Construye una URL con los parámetros proporcionados."""
    return f'{BASE_URL}?{urlencode(query)}'


def prompt_for_url():
    """Muestra un cuadro de diálogo para solicitar una nueva URL y la guarda en los ajustes."""
    current_url = ADDON.getSetting('scraper_url')
    dialog = xbmcgui.Dialog()
    
    warning_message = (
        "ADVERTENCIA: Asegúrese de que la URL proporcionada cumple con las leyes de su país. "
        "No apoyamos ni promovemos el acceso a contenido ilegal."
    )
    dialog.ok("Advertencia Legal", warning_message)
    
    new_url = dialog.input("Introduce la nueva URL a escanear", defaultt=current_url, type=xbmcgui.INPUT_ALPHANUM)

    # Si no se introduce una nueva URL, usar la anterior
    if not new_url:
        new_url = current_url

    if is_valid_url(new_url):
        # Guardar la nueva URL en los ajustes
        ADDON.setSetting('scraper_url', new_url)
        xbmcgui.Dialog().notification("URL actualizada", f"Se ha cambiado a: {new_url}", xbmcgui.NOTIFICATION_INFO, 3000)
        
        # Forzar la actualización del directorio actual
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmcgui.Dialog().notification("Error", "La URL proporcionada no es válida.", xbmcgui.NOTIFICATION_ERROR, 3000)


def list_main_menu():
    """Crea el menú principal con las opciones para ver streams y cambiar la URL."""
    # Opción para ver streams en la página secundaria
    list_item_streams = xbmcgui.ListItem(label="Ver streams")
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE, 
        url=build_url({'action': 'view_streams'}), 
        listitem=list_item_streams, 
        isFolder=True
    )
    
    # Opción para cambiar la URL sin mostrar la URL actual
    list_item_url = xbmcgui.ListItem(label="Cambiar o actualizar URL de origen")
    list_item_url.setArt({'icon': 'DefaultAddonsUpdates.png'})  # Icono para cambiar URL
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE, 
        url=build_url({'action': 'change_url'}), 
        listitem=list_item_url, 
        isFolder=False
    )

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_streams():
    """Lista los streams en la interfaz de Kodi en la página secundaria."""
    if not is_valid_url(SCRAPER_URL):
        xbmcgui.Dialog().ok("Error", "La URL proporcionada no es válida.")
        return

    streams = extract_stream_info(SCRAPER_URL)

    for stream_info, links in streams:
        for link in links:
            list_item = xbmcgui.ListItem(label=stream_info)
            list_item.setInfo("video", {"title": stream_info})

            if link.startswith("#"):
                # Comentario, no es reproducible
                xbmcplugin.addDirectoryItem(
                    handle=ADDON_HANDLE, url=link, listitem=list_item, isFolder=False
                )
            else:
                # Verificar tipo de enlace (magnet o acestream) y personalizar el ícono
                if link.startswith("magnet:"):
                    magnet_hash = re.search(r'btih:([a-fA-F0-9]{40})', link)
                    if magnet_hash:
                        infohash = magnet_hash.group(1)
                        new_link = f"plugin://script.module.horus?action=play&infohash={infohash}"
                    else:
                        new_link = link
                    list_item.setArt({'icon': 'special://home/addons/plugin.video.extractor/resources/media/Magnet.png'})
                elif link.startswith("acestream://"):
                    acestream_id = link.split("://")[1]
                    new_link = f"plugin://script.module.horus?action=play&id={acestream_id}"
                    list_item.setArt({'icon': 'special://home/addons/plugin.video.extractor/resources/media/Acestream.png'})
                else:
                    new_link = link
                    list_item.setArt({'icon': 'DefaultVideo.png'})

                list_item.setProperty("IsPlayable", "true")
                xbmcplugin.addDirectoryItem(
                    handle=ADDON_HANDLE, url=new_link, listitem=list_item, isFolder=False
                )

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def router(paramstring):
    """Lógica del enrutador para manejar las acciones y el menú principal."""
    params = dict(parse_qsl(paramstring))
    action = params.get('action')

    if action == 'view_streams':
        list_streams()  # Muestra los streams en la página secundaria
    elif action == 'change_url':
        prompt_for_url()  # Cambia la URL
    else:
        list_main_menu()  # Muestra el menú principal


if __name__ == '__main__':
    if len(sys.argv) > 2:
        router(sys.argv[2][1:])
    else:
        router('')